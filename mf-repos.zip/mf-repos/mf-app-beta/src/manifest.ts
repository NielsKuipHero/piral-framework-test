import type { AppManifest } from "@nielskuiphero/shared-types";

const baseUrl = import.meta.env.VITE_SELF_URL || "http://localhost:5002";

export const manifest: AppManifest = {
	name: "app-beta",
	displayName: "Beta",
	menuItems: [
		{
			path: "/beta",
			label: "Beta Home",
			icon: "dashboard",
		},
		{
			path: "/beta/config",
			label: "Configuratie",
			icon: "settings",
		},
	],
	remoteEntry: `${baseUrl}/assets/remoteEntry.js`,
	exposedComponent: "./RemoteApp",
};
