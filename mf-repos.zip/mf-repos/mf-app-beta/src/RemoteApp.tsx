interface RemoteAppProps {
	route?: string;
}

export default function RemoteApp({ route }: RemoteAppProps) {
	return (
		<div className="remote-app remote-app--beta">
			<div className="remote-app__header">
				<span className="remote-app__badge">Beta</span>
				<h2 className="remote-app__title">Beta Module</h2>
			</div>
			<div className="remote-app__content">
				<p className="remote-app__route">
					Route: <code>{route || "/beta"}</code>
				</p>

				<div className="remote-app__section">
					<h3>Lorem Ipsum</h3>
					<p>
						Sed ut perspiciatis unde omnis iste natus error sit voluptatem
						accusantium doloremque laudantium, totam rem aperiam, eaque ipsa
						quae ab illo inventore veritatis et quasi architecto beatae
						vitae dicta sunt explicabo.
					</p>
					<p>
						Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit
						aut fugit, sed quia consequuntur magni dolores eos qui ratione
						voluptatem sequi nesciunt.
					</p>
				</div>

				<div className="remote-app__section">
					<h3>Configuratie</h3>
					<ul className="remote-app__list">
						<li>Systeem instellingen beheren</li>
						<li>Gebruikersvoorkeuren aanpassen</li>
						<li>Notificatie configuratie</li>
					</ul>
				</div>
			</div>
		</div>
	);
}

export { manifest } from "./manifest";
