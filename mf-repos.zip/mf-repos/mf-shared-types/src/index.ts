/**
 * Menu item configuration for child apps
 */
export interface MenuItem {
	/** Route path (e.g., "/alpha/dashboard") */
	path: string;
	/** Display label in navigation */
	label: string;
	/** Optional icon name */
	icon?: string;
}

/**
 * App manifest that each child app must export
 */
export interface AppManifest {
	/** Unique app identifier (e.g., "app-alpha") */
	name: string;
	/** Human-readable display name */
	displayName: string;
	/** Menu items this app contributes */
	menuItems: MenuItem[];
	/** URL to the remote entry file */
	remoteEntry: string;
	/** Name of the exposed component (e.g., "./RemoteApp") */
	exposedComponent: string;
}

/**
 * Remote app configuration used by the master framework
 */
export interface RemoteAppConfig extends AppManifest {
	/** Federation remote name (e.g., "app_alpha") */
	remoteName: string;
}


