interface RemoteAppProps {
	route?: string;
}

export default function RemoteApp({ route }: RemoteAppProps) {
	return (
		<div className="remote-app remote-app--gamma">
			<div className="remote-app__header">
				<span className="remote-app__badge">Gamma</span>
				<h2 className="remote-app__title">Gamma Module</h2>
			</div>
			<div className="remote-app__content">
				<p className="remote-app__route">
					Route: <code>{route || "/gamma"}</code>
				</p>

				<div className="remote-app__section">
					<h3>Lorem Ipsum</h3>
					<p>
						At vero eos et accusamus et iusto odio dignissimos ducimus qui
						blanditiis praesentium voluptatum deleniti atque corrupti quos
						dolores et quas molestias excepturi sint occaecati cupiditate
						non provident.
					</p>
					<p>
						Similique sunt in culpa qui officia deserunt mollitia animi, id
						est laborum et dolorum fuga. Et harum quidem rerum facilis est
						et expedita distinctio.
					</p>
				</div>

				<div className="remote-app__section">
					<h3>Team Beheer</h3>
					<ul className="remote-app__list">
						<li>Teamleden overzicht</li>
						<li>Rol en permissie beheer</li>
						<li>Activiteiten logboek</li>
					</ul>
				</div>
			</div>
		</div>
	);
}

export { manifest } from "./manifest";
