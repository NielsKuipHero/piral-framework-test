import type { AppManifest } from "@nielskuiphero/shared-types";

const baseUrl = import.meta.env.VITE_SELF_URL || "http://localhost:5003";

export const manifest: AppManifest = {
	name: "app-gamma",
	displayName: "Gamma",
	menuItems: [
		{
			path: "/gamma",
			label: "Gamma Home",
			icon: "dashboard",
		},
		{
			path: "/gamma/team",
			label: "Team Beheer",
			icon: "users",
		},
	],
	remoteEntry: `${baseUrl}/assets/remoteEntry.js`,
	exposedComponent: "./RemoteApp",
};
