interface RemoteAppProps {
	route?: string;
}

export default function RemoteApp({ route }: RemoteAppProps) {
	return (
		<div className="remote-app remote-app--alpha">
			<div className="remote-app__header">
				<span className="remote-app__badge">Alpha</span>
				<h2 className="remote-app__title">Alpha Module</h2>
			</div>
			<div className="remote-app__content">
				<p className="remote-app__route">
					Route: <code>{route || "/alpha"}</code>
				</p>

				<div className="remote-app__section">
					<h3>Lorem Ipsum</h3>
					<p>
						Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do
						eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
						enim ad minim veniam, quis nostrud exercitation ullamco laboris
						nisi ut aliquip ex ea commodo consequat.
					</p>
					<p>
						Duis aute irure dolor in reprehenderit in voluptate velit esse
						cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat
						cupidatat non proident, sunt in culpa qui officia deserunt
						mollit anim id est laborum.
					</p>
				</div>

				<div className="remote-app__section">
					<h3>Features</h3>
					<ul className="remote-app__list">
						<li>Real-time data synchronisatie</li>
						<li>Geavanceerde analytics dashboard</li>
						<li>Gebruikersbeheer en rechten</li>
					</ul>
				</div>
			</div>
		</div>
	);
}

export { manifest } from "./manifest";
