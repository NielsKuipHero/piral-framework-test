import type { AppManifest } from "@nielskuiphero/shared-types";

const baseUrl = import.meta.env.VITE_SELF_URL || "http://localhost:5001";

export const manifest: AppManifest = {
	name: "app-alpha",
	displayName: "Alpha",
	menuItems: [
		{
			path: "/alpha",
			label: "Alpha Home",
			icon: "dashboard",
		},
		{
			path: "/alpha/reports",
			label: "Rapportages",
			icon: "document",
		},
	],
	remoteEntry: `${baseUrl}/assets/remoteEntry.js`,
	exposedComponent: "./RemoteApp",
};
