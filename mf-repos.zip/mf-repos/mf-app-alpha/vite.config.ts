import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import federation from "@originjs/vite-plugin-federation";

export default defineConfig(() => ({
	base: "/",
	plugins: [
		react(),
		federation({
			name: "app_alpha",
			filename: "remoteEntry.js",
			exposes: {
				"./RemoteApp": "./src/RemoteApp.tsx",
				"./manifest": "./src/manifest.ts",
			},
			shared: ["react", "react-dom"],
		}),
	],
	server: {
		port: 5001,
		cors: true,
	},
	build: {
		target: "esnext",
		minify: false,
	},
	preview: {
		host: "0.0.0.0",
		port: parseInt(process.env.PORT || "5001"),
		cors: true,
		allowedHosts: [".railway.app"],
		headers: {
			"Access-Control-Allow-Origin": "*",
			"Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
			"Access-Control-Allow-Headers": "Content-Type, Authorization",
		},
	},
}));
