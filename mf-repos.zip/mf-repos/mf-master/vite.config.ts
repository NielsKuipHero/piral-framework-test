import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";
import federation from "@originjs/vite-plugin-federation";

export default defineConfig(({ mode }) => {
	const env = loadEnv(mode, process.cwd(), "");

	return {
		plugins: [
			react(),
			federation({
				name: "master",
				remotes: {
					app_alpha: env.VITE_APP_ALPHA_URL || "http://localhost:5001/assets/remoteEntry.js",
					app_beta: env.VITE_APP_BETA_URL || "http://localhost:5002/assets/remoteEntry.js",
					app_gamma: env.VITE_APP_GAMMA_URL || "http://localhost:5003/assets/remoteEntry.js",
				},
				shared: ["react", "react-dom"],
			}),
		],
		server: {
			port: 5000,
			cors: true,
		},
		build: {
			target: "esnext",
			minify: false,
		},
	preview: {
		port: parseInt(process.env.PORT || "5000"),
		cors: true,
		allowedHosts: [".railway.app"],
		headers: {
				"Access-Control-Allow-Origin": "*",
				"Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
				"Access-Control-Allow-Headers": "Content-Type, Authorization",
			},
		},
	};
});
