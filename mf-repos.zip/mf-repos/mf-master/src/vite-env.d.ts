/// <reference types="vite/client" />

// Module Federation remote declarations
declare module "app_alpha/RemoteApp" {
	import type { ComponentType } from "react";
	const RemoteApp: ComponentType<{ route?: string }>;
	export default RemoteApp;
}

declare module "app_alpha/manifest" {
	import type { AppManifest } from "@mf-poc/shared-types";
	export const manifest: AppManifest;
}

declare module "app_beta/RemoteApp" {
	import type { ComponentType } from "react";
	const RemoteApp: ComponentType<{ route?: string }>;
	export default RemoteApp;
}

declare module "app_beta/manifest" {
	import type { AppManifest } from "@mf-poc/shared-types";
	export const manifest: AppManifest;
}

declare module "app_gamma/RemoteApp" {
	import type { ComponentType } from "react";
	const RemoteApp: ComponentType<{ route?: string }>;
	export default RemoteApp;
}

declare module "app_gamma/manifest" {
	import type { AppManifest } from "@mf-poc/shared-types";
	export const manifest: AppManifest;
}


