import React, { Suspense, useState, useEffect } from "react";
import type { RemoteAppConfig } from "@nielskuiphero/shared-types";

// Lazy load remote components
const AlphaApp = React.lazy(() => import("app_alpha/RemoteApp"));
const BetaApp = React.lazy(() => import("app_beta/RemoteApp"));
const GammaApp = React.lazy(() => import("app_gamma/RemoteApp"));

// Map remote names to lazy components
const remoteComponents: Record<string, React.LazyExoticComponent<React.ComponentType<{ route?: string }>>> = {
	app_alpha: AlphaApp,
	app_beta: BetaApp,
	app_gamma: GammaApp,
};

// Get base URLs from environment or use localhost defaults
const alphaUrl = import.meta.env.VITE_APP_ALPHA_URL?.replace("/assets/remoteEntry.js", "") || "http://localhost:5001";
const betaUrl = import.meta.env.VITE_APP_BETA_URL?.replace("/assets/remoteEntry.js", "") || "http://localhost:5002";
const gammaUrl = import.meta.env.VITE_APP_GAMMA_URL?.replace("/assets/remoteEntry.js", "") || "http://localhost:5003";

// Fallback manifest data
const fallbackRemoteApps: RemoteAppConfig[] = [
	{
		name: "app-alpha",
		displayName: "Dashboard",
		remoteName: "app_alpha",
		menuItems: [
			{ path: "/alpha", label: "Overview", icon: "dashboard" },
			{ path: "/alpha/analytics", label: "Analytics", icon: "chart" },
			{ path: "/alpha/reports", label: "Reports", icon: "document" },
		],
		remoteEntry: `${alphaUrl}/assets/remoteEntry.js`,
		exposedComponent: "./RemoteApp",
	},
	{
		name: "app-beta",
		displayName: "CV Parser",
		remoteName: "app_beta",
		menuItems: [
			{ path: "/beta", label: "Upload CV", icon: "upload" },
			{ path: "/beta/results", label: "Parse Results", icon: "document" },
			{ path: "/beta/stats", label: "Statistics", icon: "chart" },
		],
		remoteEntry: `${betaUrl}/assets/remoteEntry.js`,
		exposedComponent: "./RemoteApp",
	},
	{
		name: "app-gamma",
		displayName: "Hero Scraping",
		remoteName: "app_gamma",
		menuItems: [
			{ path: "/gamma", label: "Interim Opdrachten", icon: "search" },
			{ path: "/gamma/matching", label: "Matching", icon: "users" },
			{ path: "/gamma/settings", label: "Instellingen", icon: "settings" },
		],
		remoteEntry: `${gammaUrl}/assets/remoteEntry.js`,
		exposedComponent: "./RemoteApp",
	},
];

// Icons
function IconDashboard() {
	return (
		<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
			<rect x="3" y="3" width="7" height="7" rx="1" />
			<rect x="14" y="3" width="7" height="7" rx="1" />
			<rect x="3" y="14" width="7" height="7" rx="1" />
			<rect x="14" y="14" width="7" height="7" rx="1" />
		</svg>
	);
}

function IconChart() {
	return (
		<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
			<path d="M18 20V10M12 20V4M6 20v-6" />
		</svg>
	);
}

function IconDocument() {
	return (
		<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
			<path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" />
			<path d="M14 2v6h6M16 13H8M16 17H8M10 9H8" />
		</svg>
	);
}

function IconUpload() {
	return (
		<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
			<path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M17 8l-5-5-5 5M12 3v12" />
		</svg>
	);
}

function IconSearch() {
	return (
		<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
			<circle cx="11" cy="11" r="8" />
			<path d="M21 21l-4.35-4.35" />
		</svg>
	);
}

function IconUsers() {
	return (
		<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
			<path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" />
			<circle cx="9" cy="7" r="4" />
			<path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75" />
		</svg>
	);
}

function IconSettings() {
	return (
		<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
			<circle cx="12" cy="12" r="3" />
			<path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-2 2 2 2 0 01-2-2v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 01-2-2 2 2 0 012-2h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 010-2.83 2 2 0 012.83 0l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 012-2 2 2 0 012 2v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 0 2 2 0 010 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 012 2 2 2 0 01-2 2h-.09a1.65 1.65 0 00-1.51 1z" />
		</svg>
	);
}

function IconMenu() {
	return (
		<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
			<line x1="3" y1="12" x2="21" y2="12" />
			<line x1="3" y1="6" x2="21" y2="6" />
			<line x1="3" y1="18" x2="21" y2="18" />
		</svg>
	);
}

function IconChevronDown() {
	return (
		<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="nav-group__chevron">
			<path d="M6 9l6 6 6-6" />
		</svg>
	);
}

const iconMap: Record<string, React.FC> = {
	dashboard: IconDashboard,
	chart: IconChart,
	document: IconDocument,
	upload: IconUpload,
	search: IconSearch,
	users: IconUsers,
	settings: IconSettings,
};

function getIcon(iconName?: string) {
	if (!iconName) return null;
	const Icon = iconMap[iconName];
	return Icon ? <Icon /> : null;
}

// Loading component
function LoadingSpinner() {
	return (
		<div className="loading">
			<div className="loading__spinner" />
			<p>Module laden...</p>
		</div>
	);
}

// Navigation group icons
const groupIcons: Record<string, string> = {
	"Dashboard": "📊",
	"CV Parser": "📄",
	"Hero Scraping": "🔍",
};

export default function App() {
	const [remoteApps, setRemoteApps] = useState<RemoteAppConfig[]>([]);
	const [activePath, setActivePath] = useState<string>("/alpha");
	const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
	const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set(["app-alpha"]));
	const [loading, setLoading] = useState(true);

	useEffect(() => {
		setTimeout(() => {
			setRemoteApps(fallbackRemoteApps);
			setLoading(false);
		}, 500);
	}, []);

	const toggleGroup = (groupName: string) => {
		setExpandedGroups(prev => {
			const next = new Set(prev);
			if (next.has(groupName)) {
				next.delete(groupName);
			} else {
				next.add(groupName);
			}
			return next;
		});
	};

	const activeApp = remoteApps.find((app) =>
		app.menuItems.some(
			(item) =>
				activePath === item.path || activePath.startsWith(item.path + "/")
		)
	);

	const RemoteComponent = activeApp
		? remoteComponents[activeApp.remoteName]
		: null;

	const activeNavItem = remoteApps.find(app => 
		app.menuItems.some(item => item.path === activePath)
	)?.displayName || "Dashboard";

	return (
		<div className="app">
			{/* Header */}
			<header className="header">
				<div className="header__left">
					<div className="header__logo">
						<div className="header__logo-icon">H</div>
						<span className="header__logo-text">Hero Platform</span>
					</div>
					<nav className="header__nav">
						<button 
							className={`header__nav-btn ${activeNavItem === "Dashboard" ? "header__nav-btn--active" : ""}`}
							onClick={() => setActivePath("/alpha")}
						>
							Dashboard
						</button>
						<button 
							className={`header__nav-btn ${activeNavItem === "CV Parser" ? "header__nav-btn--active" : ""}`}
							onClick={() => setActivePath("/beta")}
						>
							CV Parser
						</button>
						<button 
							className={`header__nav-btn ${activeNavItem === "Hero Scraping" ? "header__nav-btn--active" : ""}`}
							onClick={() => setActivePath("/gamma")}
						>
							Hero Scraping
						</button>
					</nav>
				</div>
				<div className="header__right">
					<div className="header__user">
						<div className="header__user-avatar">NK</div>
						<span>Niels Kuip</span>
					</div>
				</div>
			</header>

			<div className="app__body">
				{/* Sidebar */}
				<aside className={`sidebar ${sidebarCollapsed ? "sidebar--collapsed" : ""}`}>
					<div className="sidebar__header">
						{!sidebarCollapsed && <span className="sidebar__title">Navigation</span>}
						<button
							className="sidebar__toggle"
							onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
							aria-label="Toggle sidebar"
						>
							<IconMenu />
						</button>
					</div>

					<nav className="sidebar__nav">
						{loading ? (
							<div className="loading">Laden...</div>
						) : (
							remoteApps.map((app) => (
								<div 
									key={app.name} 
									className={`nav-group ${expandedGroups.has(app.name) ? "nav-group--expanded" : ""}`}
								>
									<div 
										className="nav-group__header"
										onClick={() => toggleGroup(app.name)}
									>
										<div className="nav-group__title">
											<span className="nav-group__icon">{groupIcons[app.displayName] || "📁"}</span>
											{!sidebarCollapsed && app.displayName}
										</div>
										{!sidebarCollapsed && <IconChevronDown />}
									</div>
									{!sidebarCollapsed && (
										<div className="nav-group__items">
											{app.menuItems.map((item) => (
												<button
													key={item.path}
													className={`nav-item ${activePath === item.path ? "nav-item--active" : ""}`}
													onClick={() => setActivePath(item.path)}
												>
													<span className="nav-item__icon">{getIcon(item.icon)}</span>
													<span className="nav-item__label">{item.label}</span>
												</button>
											))}
										</div>
									)}
								</div>
							))
						)}
					</nav>

					{!sidebarCollapsed && (
						<div className="sidebar__help">
							<div className="sidebar__help-title">Need Help?</div>
							<p className="sidebar__help-text">
								Heb je vragen of hulp nodig? Neem contact op met support.
							</p>
							<button className="sidebar__help-btn">Contact Support</button>
						</div>
					)}
				</aside>

				{/* Main content */}
				<main className="main">
					<div className="main__content">
						{loading ? (
							<LoadingSpinner />
						) : RemoteComponent ? (
							<Suspense fallback={<LoadingSpinner />}>
								<RemoteComponent route={activePath} />
							</Suspense>
						) : (
							<div className="dashboard">
								{/* Metrics Grid */}
								<div className="metrics-grid">
									<div className="metric-card metric-card--blue">
										<div className="metric-card__title">CV's Geparsed</div>
										<div className="metric-card__value">-</div>
										<div className="metric-card__subtitle">Data wordt geladen...</div>
									</div>
									<div className="metric-card metric-card--orange">
										<div className="metric-card__title">Interim Opdrachten</div>
										<div className="metric-card__value">-</div>
										<div className="metric-card__subtitle">Data wordt geladen...</div>
									</div>
									<div className="metric-card metric-card--green">
										<div className="metric-card__title">Matches</div>
										<div className="metric-card__value">-</div>
										<div className="metric-card__subtitle">Data wordt geladen...</div>
									</div>
									<div className="metric-card metric-card--yellow">
										<div className="metric-card__title">Actieve Gebruikers</div>
										<div className="metric-card__value">-</div>
										<div className="metric-card__subtitle">Data wordt geladen...</div>
									</div>
								</div>

								{/* Welcome Section */}
								<div className="welcome">
									<h1 className="welcome__title">Welkom bij Hero Platform</h1>
									<p className="welcome__description">
										Dit is het centrale platform voor al je Hero tools en services. 
										Selecteer een module in het menu om te beginnen.
									</p>
									<ul className="welcome__list">
										<li><strong>Dashboard:</strong> Bekijk overzichten, analytics en rapportages</li>
										<li><strong>CV Parser:</strong> Upload en parse CV's automatisch</li>
										<li><strong>Hero Scraping:</strong> Vind interim opdrachten en matches</li>
									</ul>
								</div>
							</div>
						)}
					</div>
				</main>
			</div>
		</div>
	);
}
