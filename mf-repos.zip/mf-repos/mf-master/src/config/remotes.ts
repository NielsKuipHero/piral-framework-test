import type { RemoteAppConfig, AppManifest } from "@nielskuiphero/shared-types";

/**
 * Basis configuratie voor remote apps.
 * De menu-items worden runtime opgehaald uit de manifests van de child apps.
 */
export const remoteAppsConfig: Array<{
	remoteName: string;
	remoteEntry: string;
}> = [
	{
		remoteName: "app_alpha",
		remoteEntry: import.meta.env.VITE_APP_ALPHA_URL || "http://localhost:5001/assets/remoteEntry.js",
	},
	{
		remoteName: "app_beta",
		remoteEntry: import.meta.env.VITE_APP_BETA_URL || "http://localhost:5002/assets/remoteEntry.js",
	},
	{
		remoteName: "app_gamma",
		remoteEntry: import.meta.env.VITE_APP_GAMMA_URL || "http://localhost:5003/assets/remoteEntry.js",
	},
];

/**
 * Haalt het manifest op van een remote app
 */
export async function fetchManifest(
	remoteName: string
): Promise<AppManifest | null> {
	try {
		// Dynamic import van de manifest module
		const manifestModule = await import(
			/* @vite-ignore */ `${remoteName}/manifest`
		);
		return manifestModule.manifest;
	} catch (error) {
		console.warn(`Could not load manifest for ${remoteName}:`, error);
		return null;
	}
}

/**
 * Haalt alle manifests op en bouwt de complete remote app configuratie
 */
export async function loadAllRemoteApps(): Promise<RemoteAppConfig[]> {
	const results = await Promise.all(
		remoteAppsConfig.map(async (config) => {
			const manifest = await fetchManifest(config.remoteName);
			if (!manifest) return null;

			return {
				...manifest,
				remoteName: config.remoteName,
			} as RemoteAppConfig;
		})
	);

	return results.filter((r): r is RemoteAppConfig => r !== null);
}
