# Hero Platform - Complete Design Specification

## Overview
Complete design specification for the Hero Platform web application, including all components, layouts, colors, and styling details based on analysis of the live application.

## Brand Colors & Design System

### Primary Colors
- **Hero Blue (Primary)**: `#073889`
- **Hero Orange (Accent)**: `#f46015` 
- **Hero Yellow**: `#ffbd0d`
- **Hero Green**: `#22c55e` (for success states)

### Color Variations
- **Hero Blue Soft**: `#d3e6f0` (light backgrounds)
- **Hero Blue Hairline**: `#f8fafc` (very light backgrounds)
- **Hero Orange Thin**: Light orange tint for backgrounds
- **Hero Gray Regular**: Standard text gray

### Typography
- **Primary Font**: System font stack (likely Inter or similar)
- **Header Text**: Bold, Hero Blue color
- **Body Text**: Regular weight, gray colors
- **Button Text**: Medium weight, white or Hero Blue

## Layout Structure

### Overall Layout
```
┌─────────────────────────────────────────────────────────────┐
│                        HEADER (80px)                        │
├─────────────────┬─────────────────────┬─────────────────────┤
│   RIGHT SIDEBAR │    MAIN CONTENT     │    LEFT SIDEBAR     │
│   (320px width) │    (flex-1)         │    (256px width)    │
│   Navigation    │    Dashboard/Views  │    App Info         │
│                 │                     │                     │
│                 │                     │                     │
│                 │                     │                     │
└─────────────────┴─────────────────────┴─────────────────────┘
```

## Component Specifications

### 1. Authentication Screen (Login)

**Layout:**
- Full screen centered modal
- Light gray background (`bg-hero-blue-hairline`)
- White card container with rounded corners
- Shadow for depth

**Content:**
- **Title**: "Welcome to Hero Platform" (Hero Blue, large font)
- **Subtitle**: "Please sign in with your Microsoft account to continue." (gray text)
- **Primary Button**: "Sign in with Microsoft" (Hero Orange background, white text)
- **Secondary Button**: "Sign in with LinkedIn" (Hero Blue background, white text)
- **Footer Text**: "Having trouble signing in? Contact your administrator for support." (small gray text)

### 2. Header Component

**Specifications:**
- **Height**: 80px
- **Background**: Hero Blue (`#073889`)
- **Text Color**: White
- **Shadow**: Large shadow for depth

**Left Section:**
- **Hero Logo**: White/inverted logo, 32px height
- **Navigation Buttons**: Dashboard, CV Parser, Hero Scraping, Admin
  - Inactive: White text with orange hover
  - Active: Hero Orange background with white text
  - Padding: 12px horizontal, 8px vertical
  - Rounded corners

**Right Section:**
- **Download Icon**: White icon with orange hover
- **Auth Button**: User authentication controls

### 3. Right Sidebar (Navigation - Left Position)

**Specifications:**
- **Width**: 320px
- **Background**: White
- **Border**: Right border in Hero Blue Soft

**Content:**
- **Title**: "Navigation" (Hero Blue, semibold)
- **Menu Items**: Expandable accordion sections
  - Dashboard (📊): Overview, Analytics, Reports
  - CV Parser (📄): Upload CV, Parse Results, Statistics  
  - Hero Scraping (🔍): Interim Opdrachten, Auto Refresh, Matching
  - Admin (🛡️): Systeem Status, Gebruikers, Instellingen, Logs
  - Projects (📁): Active Projects, Completed, Templates, Archive
  - Team (👥): Members, Roles, Permissions, Invitations
  - Settings (⚙️): General, Security, Integrations, Billing

**Menu Item Styling:**
- **Container**: Border with Hero Blue Soft, rounded corners
- **Header**: Hero Blue Hairline background, Hero Blue text
- **Expanded Items**: White background, gray text with blue hover
- **Icons**: Emoji icons (can be replaced with proper icons)
- **Chevron**: Rotates when expanded

**Help Section:**
- **Background**: Hero Orange Thin
- **Title**: "Need Help?" (Hero Orange text)
- **Button**: Hero Orange background, white text

### 4. Main Content Area (Dashboard)

**Container:**
- **Background**: White
- **Padding**: 24px
- **Border**: Hero Blue Soft border
- **Rounded**: Large rounded corners

**Metrics Cards Grid:**
```
┌─────────────┬─────────────┬─────────────┬─────────────┐
│  CV's       │  Interim    │   Matches   │  Actieve    │
│  Geparsed   │ Opdrachten  │             │ Gebruikers  │
│ (Hero Blue) │(Hero Orange)│(Hero Green) │(Hero Yellow)│
└─────────────┴─────────────┴─────────────┴─────────────┘
```

**Card Specifications:**
- **Layout**: 4 columns on desktop, responsive
- **Padding**: 16px
- **Rounded**: Medium rounded corners
- **Text Color**: White
- **Content**:
  - Title: Large semibold text
  - Value: Extra large bold number ("-" for loading)
  - Subtitle: Small text "Data wordt geladen..."

**Card Colors:**
1. **CV's Geparsed**: Hero Blue background
2. **Interim Opdrachten**: Hero Orange background  
3. **Matches**: Hero Green background
4. **Actieve Gebruikers**: Hero Yellow background, Hero Blue text

**Welcome Section:**
- **Title**: "Welkom bij Hero Platform" (Hero Blue, large)
- **Description**: Gray text explaining the platform
- **List Items**: Bullet points with bold labels

### 5. Left Sidebar (App Info - Right Position)

**Specifications:**
- **Width**: 256px
- **Background**: Hero Blue Hairline
- **Border**: Left border in Hero Blue Soft

**Content Sections:**

**System Status Card:**
- **Background**: White with shadow
- **Title**: "System Status" (Hero Blue, small semibold)
- **Status Indicator**: Green dot + "All systems operational"

**Quick Stats Card:**
- **Background**: White with shadow
- **Title**: "Quick Stats" (Hero Blue, small semibold)
- **Stats Rows**:
  - Active Users: 1,247
  - Projects: 89
  - Tasks: 342
- **Layout**: Label on left, value on right (Hero Blue, medium weight)

**Recent Activity Card:**
- **Background**: White with shadow
- **Title**: "Recent Activity" (Hero Blue, small semibold)
- **Activity Items**:
  - Action description (medium weight)
  - Timestamp (gray, small)

## Responsive Behavior

### Desktop (1200px+)
- Full three-column layout as specified
- All sidebars visible
- 4-column metrics grid

### Tablet (768px - 1199px)
- Collapse sidebars to icons or hide
- 2-column metrics grid
- Maintain header navigation

### Mobile (< 768px)
- Single column layout
- Hamburger menu for navigation
- Stacked metrics cards
- Simplified header

## Interactive States

### Buttons
- **Default**: Specified background colors
- **Hover**: Slightly darker shade or Hero Orange for white buttons
- **Active**: Hero Orange background for navigation
- **Focus**: Outline in Hero Blue

### Navigation
- **Active State**: Hero Orange background, white text
- **Hover State**: Hero Orange text color
- **Transition**: Smooth color transitions (200ms)

### Cards
- **Hover**: Subtle shadow increase
- **Loading**: Skeleton states or "-" placeholders

## Accessibility

### Color Contrast
- Ensure WCAG AA compliance for all text/background combinations
- Hero Blue on white: High contrast ✓
- White on Hero Orange: High contrast ✓
- White on Hero Blue: High contrast ✓

### Focus States
- Visible focus indicators on all interactive elements
- Keyboard navigation support
- Screen reader friendly labels

## Implementation Notes

### CSS Classes (Tailwind-based)
```css
/* Primary Colors */
.bg-hero-blue { background-color: #073889; }
.bg-hero-orange { background-color: #f46015; }
.bg-hero-yellow { background-color: #ffbd0d; }
.bg-hero-green-regular { background-color: #22c55e; }

/* Light Variants */
.bg-hero-blue-hairline { background-color: #f8fafc; }
.bg-hero-blue-soft { background-color: #d3e6f0; }

/* Text Colors */
.text-hero-blue { color: #073889; }
.text-hero-orange { color: #f46015; }
```

### Component Structure
- Modular React components
- TypeScript interfaces for props
- Consistent spacing using Tailwind classes
- Responsive design with mobile-first approach

## Assets Needed

### Icons
- Hero logo (SVG format, white version for header)
- Navigation icons (can use emoji or proper icon library)
- System status indicators
- Chevron/arrow icons for expandable menus

### Images
- Placeholder images for empty states
- Loading states/skeletons
- Error state illustrations

## Design File Organization

### Figma Structure (when creating)
```
📁 Hero Platform Design
├── 🎨 Design System
│   ├── Colors
│   ├── Typography
│   ├── Components
│   └── Icons
├── 📱 Screens
│   ├── Authentication
│   ├── Dashboard
│   ├── CV Parser
│   ├── Hero Scraping
│   └── Admin
└── 📐 Layout Templates
    ├── Desktop Layout
    ├── Tablet Layout
    └── Mobile Layout
```

This specification provides complete design guidance for recreating the Hero Platform interface in any design tool or for development implementation.
